package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;

public class MyHomePage extends ProjectSpecificMethods{
	
	
      public MyLeadsPage clickLeadsLink() {
    	  String leadsValue = prop.getProperty("MyHomePage_leads_linkText");
		driver.findElement(By.linkText(leadsValue)).click();
		return new MyLeadsPage();

	}
}
