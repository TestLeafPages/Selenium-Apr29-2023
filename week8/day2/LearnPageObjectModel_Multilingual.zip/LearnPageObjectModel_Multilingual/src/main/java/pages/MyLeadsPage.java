package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;

public class MyLeadsPage extends ProjectSpecificMethods{
	
    public CreateLeadPage clickCreateLeadButton() {
		driver.findElement(By.xpath(prop.getProperty("MyLeadsPage_createLead_linkText"))).click();
		return new CreateLeadPage();

	}
    
   
}
