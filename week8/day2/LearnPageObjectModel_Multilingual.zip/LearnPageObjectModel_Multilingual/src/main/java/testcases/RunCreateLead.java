package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class RunCreateLead extends ProjectSpecificMethods{
	
	
	@Test
	public void runCreateLead() throws InterruptedException {
         LoginPage lp = new LoginPage();
         lp.enterUsername()
         .enterPassword()
         .clickLoginButton()
         .verifyHomePage()
         .clickCRMSFALink()
         .clickLeadsLink()
         .clickCreateLeadButton()
         .enterCompanyName("TestLeaf")
         .enterFirstName("Subraja")
         .enterLastName("Subi")
         .clickSubmitButton()
         .verifyCreateLead("TestLeaf");

	}

}
