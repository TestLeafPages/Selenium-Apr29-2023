package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests{

	public static ChromeDriver driver;
	public String excelFilename;
	public static Properties prop;

	@BeforeMethod
	public void preCondition() throws IOException {
		//set up the path of the properties file
		FileInputStream fis = new FileInputStream("src/main/resources/config_fr.properties");
		//Create an object for properties class
		prop = new Properties();
		//load this fis in the prop class
		prop.load(fis);


		driver=new ChromeDriver();
		System.out.println(driver);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("http://leaftaps.com/opentaps/control/main");

	}

	@AfterMethod
	public void postCondition() {
		driver.quit();
	}

	
}
