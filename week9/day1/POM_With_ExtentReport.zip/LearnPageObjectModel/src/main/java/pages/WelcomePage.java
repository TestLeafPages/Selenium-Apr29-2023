package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods{

	
	public WelcomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	  public WelcomePage verifyHomePage() throws IOException {
		  try {
			String title = driver.getTitle();
				if (title.contains("Leaftaps")) {
					System.out.println("Login successfull");
				}
				else {
					System.out.println("Login not successfull");
				}
				reportStep("Homepage is displayed", "pass");
		} catch (Exception e) {
			reportStep("Homepage is not displayed", "fail");
		}
        return this;

	}
	  
	  public MyHomePage clickCRMSFALink() {
		  driver.findElement(By.linkText("CRM/SFA")).click();
		  return new MyHomePage(driver);
				  

	}
}
