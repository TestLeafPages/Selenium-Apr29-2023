package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class VerifyLogin extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
       excelFilename="Login";
       testName ="VerifyLogin";
       testDescription ="Verify login with valid data";
       testCategory="Smoke";
       testAuthor="Hari";

	}
	
	
	@Test(dataProvider = "sendData")
	public void runLogin(String uName,String pWord) throws InterruptedException, IOException {
		System.out.println(driver);
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername(uName).
		enterPassword(pWord).
		clickLoginButton().
		verifyHomePage();
		
		
		
//		lp.enterUsername();
//		lp.enterPassword();
//		lp.clickLoginButton();
//		
//		WelcomePage wp = new WelcomePage();
//		wp.verifyHomePage();
//		wp.clickCRMSFALink();
//		
//		MyHomePage hp = new MyHomePage();
//		hp.clickLeadsLink();
		
	}

}
